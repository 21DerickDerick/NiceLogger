//
//  NiceLogger.h
//  NiceLogger
//
//  Created by Derick on 15/1/20.
//  Copyright © 2020 DerickProductions. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NiceLogger.
FOUNDATION_EXPORT double NiceLoggerVersionNumber;

//! Project version string for NiceLogger.
FOUNDATION_EXPORT const unsigned char NiceLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLogger/PublicHeader.h>


